﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp8
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int start = int.Parse(StartTextBox.Text);
                int end = int.Parse(EndTextBox.Text);

                var numbers = Enumerable.Range(start, end - start + 1).Where(x => x % 3 == 0);
                var sum = numbers.Sum();

                ResultLabel.Content = $"Сумма чисел: {sum}";
            }
            catch (FormatException)
            {
                ResultLabel.Content = "Пожалуйста, введите числовые значения";
            }
        }
    }
}
